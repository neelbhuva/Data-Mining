#!/bin/bash

python3 ngram.py